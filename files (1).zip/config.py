"""
config.py — single source of truth for every constant in the study.

Nothing in this repository hard-codes a seed, path, label set, or hyperparameter.
If a value appears in the manuscript, it is defined here.
"""

from pathlib import Path

# ----------------------------------------------------------------------------
# Reproducibility
# ----------------------------------------------------------------------------
SEED = 42                    # controls splits, shuffling, init, dropout
N_RUNS = 1                   # single run per model x configuration (see Sect. III-G)

# ----------------------------------------------------------------------------
# Paths
# ----------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parent
DATA = ROOT / "artifacts" / "data"          # corpus + normalized corpora
SPLITS = ROOT / "artifacts" / "splits"      # index files (released)
PREDS = ROOT / "artifacts" / "predictions"  # per-comment predictions (released)
CKPT = ROOT / "artifacts" / "checkpoints"
RESULTS = ROOT / "artifacts" / "results"    # tables.csv, figures, latex
LOGS = ROOT / "artifacts" / "logs"

for _p in (DATA, SPLITS, PREDS, CKPT, RESULTS, LOGS):
    _p.mkdir(parents=True, exist_ok=True)

RAW_CORPUS = DATA / "hastika.csv"           # columns: id,comment,binary_label,fine_label

# ----------------------------------------------------------------------------
# Label sets
# ----------------------------------------------------------------------------
BINARY_LABELS = ["Hate", "Non-Hate"]
FINE_LABELS = ["Gender", "Political", "Religion", "Geo-political", "Violence", "Others"]

LABELS = {"binary": BINARY_LABELS, "multiclass": FINE_LABELS}

# Expected corpus composition (Table 2). Asserted at load time so a corrupted
# or partially downloaded corpus fails loudly instead of silently changing results.
EXPECTED_BINARY_COUNTS = {"Hate": 3950, "Non-Hate": 4108}
EXPECTED_FINE_COUNTS = {
    "Gender": 1703, "Political": 699, "Religion": 478,
    "Geo-political": 232, "Violence": 277, "Others": 561,
}
EXPECTED_TOTAL = 8058

# ----------------------------------------------------------------------------
# Splits (Sect. III-B, Table 2b)
# The binary task uses all 8058 comments; the fine-grained task uses only the
# 3950 hateful comments, since the six thematic classes are defined within the
# hate class. Each task is stratified on its own label.
# ----------------------------------------------------------------------------
SPLIT_RATIOS = {"train": 0.70, "val": 0.10, "test": 0.20}

# ----------------------------------------------------------------------------
# Model registry
# group: "standard" = standard-capacity encoder (trained directly)
#        "compact"  = distilled compact encoder (knowledge-distilled student)
# The grouping criterion is distillation provenance, not parameter count —
# see Sect. III-F. ALBERT reduces memory by cross-layer parameter sharing, not
# distillation, and its inference latency is standard-capacity (Table 14).
# ----------------------------------------------------------------------------
MODELS = {
    "BERT":        dict(hf="bert-base-uncased",                        group="standard", params_m=110,  layers=12, hidden=768, ffn=3072, heads=12),
    "mBERT":       dict(hf="bert-base-multilingual-cased",             group="standard", params_m=178,  layers=12, hidden=768, ffn=3072, heads=12),
    "HateBERT":    dict(hf="GroNLP/hateBERT",                          group="standard", params_m=110,  layers=12, hidden=768, ffn=3072, heads=12),
    "XLM-R":       dict(hf="xlm-roberta-base",                         group="standard", params_m=270,  layers=12, hidden=768, ffn=3072, heads=12),
    "ALBERT":      dict(hf="albert-base-v2",                           group="standard", params_m=12,   layers=12, hidden=768, ffn=3072, heads=12),
    "TinyBERT":    dict(hf="huawei-noah/TinyBERT_General_4L_312D",     group="compact",  params_m=14.5, layers=4,  hidden=312, ffn=1200, heads=12),
    "MobileBERT":  dict(hf="google/mobilebert-uncased",                group="compact",  params_m=25,   layers=24, hidden=512, ffn=1024, heads=4),
    "DistilBERT":  dict(hf="distilbert-base-uncased",                  group="compact",  params_m=66,   layers=6,  hidden=768, ffn=3072, heads=12),
}

STANDARD = [m for m, c in MODELS.items() if c["group"] == "standard"]
COMPACT = [m for m, c in MODELS.items() if c["group"] == "compact"]

# ----------------------------------------------------------------------------
# Experimental configurations: 2 modalities x 2 tasks (Sect. III-F)
# ----------------------------------------------------------------------------
MODALITIES = ["codemixed", "translated"]
TASKS = ["binary", "multiclass"]

# ----------------------------------------------------------------------------
# Hyperparameters (Table 4). Fixed across all eight models; selection procedure
# is in analysis/hyperparam_search.py (Sect. III-G).
# ----------------------------------------------------------------------------
HP = dict(
    batch_size=16,
    lr=1e-3,                 # for the randomly initialised downstream layers
    optimizer="adam",
    adam_betas=(0.9, 0.999),
    max_epochs=10,
    early_stopping_patience=3,
    dropout=0.3,
    max_seq_len=128,
    bilstm_hidden=128,
    dense_hidden=128,
    freeze_encoder=True,     # only Bi-LSTM + dense + head are trained
)

GRID = dict(
    lr=[1e-2, 1e-3, 1e-4],
    batch_size=[8, 16, 32],
    dropout=[0.2, 0.3, 0.5],
)

# ----------------------------------------------------------------------------
# Normalization pipeline (Sect. III-C). Run OFFLINE, once, before training.
# ----------------------------------------------------------------------------
XLIT_BEAM = 4
XLIT_LANG = "kn"
NMT_SRC_TAG = "kan_Knda"
NMT_TGT_TAG = "eng_Latn"
NMT_MODEL = "ai4bharat/indictrans2-indic-en-1B"
XLIT_MODEL = "ai4bharat/IndicXlit"

# Translation-quality subset (Sect. III-D)
TQ_SUBSET_SIZE = 200
TQ_REFS = 2                  # two independent bilingual annotators


def device():
    import torch
    return "cuda" if torch.cuda.is_available() else "cpu"


def set_all_seeds(seed: int = SEED):
    """Seed every source of randomness we control."""
    import os, random
    import numpy as np
    os.environ["PYTHONHASHSEED"] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass
