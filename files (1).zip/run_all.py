"""
run_all.py — run the full grid: 8 models x 2 tasks x 2 modalities = 32 runs,
plus the four ablation runs of Table 5.

    python run_all.py                 # everything
    python run_all.py --ablation_only
    python run_all.py --seeds 42 43 44 45 46    # multi-seed replication

The --seeds option exists because multi-seed replication is the limitation
stated in Sect. VII. It writes predictions to seed-suffixed files, and
evaluate_metrics.py will then report mean +/- SD instead of point estimates.
Until it is run, the manuscript must state the single-run protocol.
"""

import argparse
import itertools
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C

# The four rows of Table 5: best model of each peer group in each setting.
ABLATION = [
    ("MobileBERT", "binary", "codemixed"),
    ("DistilBERT", "multiclass", "codemixed"),
    ("BERT", "binary", "translated"),
    ("DistilBERT", "multiclass", "translated"),
]


def call(model, task, modality, seed, no_bilstm=False):
    cmd = [sys.executable, "train.py", "--model", model, "--task", task,
           "--modality", modality, "--seed", str(seed)]
    if no_bilstm:
        cmd.append("--no_bilstm")
    print("\n" + " ".join(cmd))
    return subprocess.run(cmd, cwd=Path(__file__).resolve().parent).returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=[C.SEED])
    ap.add_argument("--models", nargs="+", default=list(C.MODELS))
    ap.add_argument("--ablation_only", action="store_true")
    ap.add_argument("--skip_ablation", action="store_true")
    a = ap.parse_args()

    if len(a.seeds) > 1:
        print(f"NOTE: {len(a.seeds)} seeds requested. Once complete, the abstract and "
              "Sect. III-G may report mean +/- SD and significance tests. Do not make "
              "that claim before these runs finish.\n")

    failed = []
    if not a.ablation_only:
        combos = list(itertools.product(a.models, C.TASKS, C.MODALITIES))
        print(f"main grid: {len(combos)} combinations x {len(a.seeds)} seed(s)")
        for seed in a.seeds:
            for model, task, modality in combos:
                if call(model, task, modality, seed):
                    failed.append((model, task, modality, seed, "main"))

    if not a.skip_ablation:
        print(f"\nablation: {len(ABLATION)} runs x {len(a.seeds)} seed(s)")
        for seed in a.seeds:
            for model, task, modality in ABLATION:
                if call(model, task, modality, seed, no_bilstm=True):
                    failed.append((model, task, modality, seed, "ablation"))

    print("\n" + "=" * 70)
    if failed:
        print(f"{len(failed)} run(s) FAILED:")
        for f in failed:
            print("  ", f)
        sys.exit(1)
    print("all runs complete. next:")
    print("  python evaluate_metrics.py          # regenerate every table")
    print("  python verify_consistency.py        # the check that catches transcription errors")
    print("  python -m analysis.pareto           # frontier + Figure 5")
    print("  python -m analysis.figure4          # translation deltas")
    print("  python -m analysis.confusion        # Figures 6 and 7")
    print("  python -m tables.make_tables        # LaTeX for Tables 5-14")


if __name__ == "__main__":
    main()
