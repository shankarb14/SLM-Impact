"""
hyperparam_search.py — the grid search of Sect. III-G (Reviewer 3, point 9).

The reviewer asked how one configuration was chosen across eight heterogeneous
models. This script implements and documents the aggregate criterion:

  1. evaluate the full 3x3x3 grid for every model on the validation split of
     the binary code-mixed configuration (27 runs per model, 216 in total),
  2. average validation Macro-F1 across models at each grid point,
  3. select the highest-mean point and fix it for all subsequent experiments,
  4. report the gap between that shared point and each model's individually
     best point, so the manuscript can state whether any model is materially
     disadvantaged by the shared setting.

Rationale for (2): per-model tuning would confound the group comparison with
tuning effort, since the two groups contain different numbers of models.

    python -m analysis.hyperparam_search --quick   # subsample for a dry run
"""

import argparse
import itertools
import sys
from pathlib import Path

import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import f1_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C
from models.classifier import EncoderBiLSTM, get_tokenizer
from models.dataset import build_loaders

TASK, MODALITY = "binary", "codemixed"
MAX_EPOCHS = 4          # short budget: the search ranks configurations, not models


def val_macro_f1(model, loader):
    model.eval()
    preds, golds = [], []
    with torch.no_grad():
        for b in loader:
            logits = model(b["input_ids"].to(C.device()), b["attention_mask"].to(C.device()))
            preds += (torch.sigmoid(logits) >= 0.5).long().cpu().tolist()
            golds += b["label"].tolist()
    return f1_score(golds, preds, average="macro", zero_division=0)


def train_short(model_key, hp, loaders):
    C.set_all_seeds()
    model = EncoderBiLSTM(model_key, 2, use_bilstm=True, hp=hp).to(C.device())
    loss_fn = nn.BCEWithLogitsLoss()
    opt = torch.optim.Adam([p for p in model.parameters() if p.requires_grad],
                           lr=hp["lr"], betas=C.HP["adam_betas"])
    best = 0.0
    for _ in range(MAX_EPOCHS):
        model.train()
        model.encoder.eval()
        for b in loaders["train"]:
            logits = model(b["input_ids"].to(C.device()), b["attention_mask"].to(C.device()))
            loss = loss_fn(logits, b["label"].float().to(C.device()))
            opt.zero_grad(); loss.backward(); opt.step()
        best = max(best, val_macro_f1(model, loaders["val"]))
    del model
    torch.cuda.empty_cache()
    return best


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--models", nargs="+", default=list(C.MODELS))
    ap.add_argument("--quick", action="store_true", help="one grid point per axis, for a dry run")
    a = ap.parse_args()

    grid = dict(lr=[1e-3], batch_size=[16], dropout=[0.3]) if a.quick else C.GRID
    points = list(itertools.product(grid["lr"], grid["batch_size"], grid["dropout"]))
    print(f"grid: {len(points)} points x {len(a.models)} models = "
          f"{len(points) * len(a.models)} short runs\n")

    rows = []
    for model_key in a.models:
        tokenizer = get_tokenizer(model_key)
        for lr, bs, do in points:
            hp = {**C.HP, "lr": lr, "batch_size": bs, "dropout": do}
            loaders, _, _ = build_loaders(TASK, MODALITY, tokenizer, batch_size=bs)
            score = train_short(model_key, hp, loaders)
            rows.append(dict(model=model_key, lr=lr, batch_size=bs, dropout=do,
                             val_macro_f1=round(score, 4)))
            print(f"  {model_key:12s} lr={lr:<7} bs={bs:<3} do={do:<4} -> {score:.4f}")

    df = pd.DataFrame(rows)
    out = C.RESULTS / "hyperparameter_search.csv"
    df.to_csv(out, index=False)

    agg = (df.groupby(["lr", "batch_size", "dropout"], as_index=False)
             .val_macro_f1.mean()
             .sort_values("val_macro_f1", ascending=False))
    print(f"\nmean validation Macro-F1 by grid point (averaged over {df.model.nunique()} models):")
    print(agg.head(10).to_string(index=False))

    best = agg.iloc[0]
    print(f"\nSELECTED: lr={best.lr}, batch_size={int(best.batch_size)}, dropout={best.dropout}")
    print("Report this point and this procedure in Sect. III-G and Table 4.\n")

    print("gap between the shared configuration and each model's own best point:")
    worst = 0.0
    for model_key, sub in df.groupby("model"):
        own = sub.val_macro_f1.max()
        shared = sub[(sub.lr == best.lr) & (sub.batch_size == best.batch_size) &
                     (sub.dropout == best.dropout)].val_macro_f1
        shared = float(shared.iloc[0]) if len(shared) else float("nan")
        gap = own - shared
        worst = max(worst, gap)
        print(f"  {model_key:12s} own best {own:.4f}  shared {shared:.4f}  gap {gap:+.4f}")

    print(f"\nlargest gap = {worst:.4f}")
    if worst > 0.01:
        print("This exceeds 0.01. Do NOT claim in Sect. III-G that every model is within")
        print("0.01 of its own best configuration — state the actual largest gap instead.")
    else:
        print("All models are within 0.01 of their own best configuration, which Sect. III-G")
        print("may state.")
    print(f"\nfull results: {out}")


if __name__ == "__main__":
    main()
