# SLM-Impact

Code for *Lightweight but Effective? Evaluating Small Language Models for Scalable
Hate Speech Detection in Low-Resource Languages* (Kavatagi, Rachh, Biradar).

Hate speech detection in Kannada–English code-mixed text: eight transformer
encoders across four configurations (raw vs. translated input × distilled
compact vs. standard-capacity encoders), on the HASTIKA corpus.

---

## Why this repository is structured the way it is

Review of the previous submission found that the aggregate columns of two result
tables could not be reconstructed from the per-class columns printed beside them.
The cause was that metrics were transcribed by hand rather than generated.

The pipeline is therefore split so that this cannot recur. `train.py` writes
**per-comment predictions and nothing else**. Every metric, table, and figure in
the paper is derived from those files by a single downstream script. Two
assertions run on every row:

1. reported Macro-F1 equals the unweighted mean of the per-class F1 values
   printed in the same row (Eq. 13);
2. reported accuracy equals the confusion-matrix diagonal.

`verify_consistency.py` reproduces the reviewer's audit on demand, and can be run
against the values as typeset in the manuscript to catch transcription errors
before submission.

---

## Install

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -c "import nltk; nltk.download('words')"   # English vocabulary for word-level LID
```

Place HASTIKA at `artifacts/data/hastika.csv` with columns
`id,comment,binary_label,fine_label`. Obtain the corpus from Kavatagi & Rachh
(2025), [doi:10.1007/s10579-025-09836-1](https://doi.org/10.1007/s10579-025-09836-1).

---

## Run

```bash
# 1. splits — separate procedures for the two tasks, seed 42, index files released
python -m data.prepare_splits

# 2. normalization — OFFLINE, once. Cached and reused by every experiment.
python -m preprocess.normalize --stage all --en_vocab path/to/english_words.txt

# 3. hyperparameter search (optional; the selected point is already in config.HP)
python -m analysis.hyperparam_search

# 4. train: 8 models × 2 tasks × 2 modalities + 4 ablation runs
python run_all.py

# 5. metrics — the ONLY place aggregates are computed
python evaluate_metrics.py --latex

# 6. audit — must pass before submission
python verify_consistency.py

# 7. figures and remaining tables
python -m analysis.figure4        # Figure 4, translation deltas
python -m analysis.pareto         # Figure 5, Pareto frontiers
python -m analysis.confusion      # Figures 6–7, error patterns
python -m analysis.efficiency --include_normalization   # Table 14
python -m preprocess.translation_quality               # Sect. III-D and Table 4b
```

Multi-seed replication, which is the limitation stated in Sect. VII:

```bash
python run_all.py --seeds 42 43 44 45 46
python evaluate_metrics.py     # now reports mean ± SD instead of point estimates
```

Do not claim averaging over runs in the manuscript until this has actually been
run. `evaluate_metrics.py` prints which regime is in force.

---

## Layout

| File | Purpose |
|---|---|
| `config.py` | Every constant: seeds, paths, model registry, label sets, hyperparameters |
| `data/prepare_splits.py` | Stratified 70:10:20 splits, separately for each task; releases index files |
| `preprocess/normalize.py` | IndicXlit → IndicTrans2, offline, with token-level LID so English spans survive |
| `preprocess/translation_quality.py` | Multi-reference BLEU/chrF++, κ, and the downstream-impact analysis (Table 4b) |
| `models/classifier.py` | Frozen encoder + Bi-LSTM; `use_bilstm=False` is the Table 5 ablation |
| `models/dataset.py` | Loaders built from the released split IDs, identical across modalities |
| `train.py` | One run; writes predictions and timing, **no metrics** |
| `run_all.py` | The full grid plus ablation; `--seeds` for replication |
| `evaluate_metrics.py` | Sole metric computation, with the two consistency assertions |
| `verify_consistency.py` | Reproduces the reviewer's audit; run against the typeset values |
| `analysis/pareto.py` | Frontiers, Figure 5, and the "reaches no frontier anywhere" census |
| `analysis/figure4.py` | Translation deltas and the two mean-Δ values quoted in the abstract |
| `analysis/confusion.py` | Figures 6–7, Religion→Political leakage, zero-recall census |
| `analysis/hyperparam_search.py` | Grid search with the documented aggregate selection criterion |
| `analysis/efficiency.py` | Table 14, plus the request-time normalization cost |
| `tables/make_tables.py` | IEEE LaTeX generated from `tables.csv`; never edit the `.tex` by hand |

---

## Where each reviewer point is addressed

| Point | Concern | Addressed in |
|---|---|---|
| 1 | Single-run vs. five-run contradiction | `config.N_RUNS`; `evaluate_metrics.py` prints the regime; `run_all.py --seeds` |
| 2 | Tables 8–9 not reconstructible | `train.py` / `evaluate_metrics.py` separation; `verify_consistency.py` |
| 3 | Conclusion may change | `analysis/pareto.py` recomputes the frontier and prints the claim to make |
| 4 | Split procedure for the two tasks | `data/prepare_splits.py` |
| 5 | Code availability | this repository |
| 6 | Downstream impact of translation error | `preprocess.translation_quality.downstream_impact` |
| 7 | Efficiency excludes normalization | `preprocess/normalize.py` (offline); `analysis/efficiency.py --include_normalization` |
| 8 | SLM / large-encoder definition | `config.MODELS[...]["group"]`, criterion documented in `config.py` |
| 9 | Hyperparameter selection across models | `analysis/hyperparam_search.py` |
| 10–11 | References and proofreading | manuscript only, not code |

---

## Reported figures that must come from a script, never from memory

- Macro-F1 and accuracy in every table → `artifacts/results/tables.csv`
- mean Δ for binary and fine-grained translation → `analysis/figure4.py`
- Pareto frontier membership and the "N of 4" count → `analysis/pareto.py`
- per-class test supports → `data/prepare_splits.py`
- Religion→Political leakage percentages → `analysis/confusion.py`
- latency, memory, throughput → `analysis/efficiency.py`

If a number in the manuscript has no script above it, it should not be in the
manuscript.
