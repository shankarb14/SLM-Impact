"""
train.py — train one (model x task x modality) and write per-comment predictions.

The script deliberately writes predictions, NOT metrics. Every aggregate value
in the manuscript is produced later by evaluate_metrics.py from these files.
Splitting the two steps is what prevents per-class and aggregate figures from
coming out of different runs, which is the defect Reviewer 3 found in Tables 8-9.

    python train.py --model MobileBERT --task binary --modality codemixed
    python train.py --model DistilBERT --task multiclass --modality codemixed --no_bilstm
"""

import argparse
import json
import sys
import time
from pathlib import Path

import pandas as pd
import torch
import torch.nn as nn

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C
from models.classifier import EncoderBiLSTM, get_tokenizer, trainable_parameters
from models.dataset import build_loaders


def run_epoch(model, loader, loss_fn, optimizer, n_classes, train: bool):
    model.train(train)
    if C.HP["freeze_encoder"]:
        model.encoder.eval()          # keep frozen BN/dropout in eval mode

    total, seen = 0.0, 0
    for batch in loader:
        ids = batch["input_ids"].to(C.device())
        mask = batch["attention_mask"].to(C.device())
        y = batch["label"].to(C.device())
        y = y.float() if n_classes == 2 else y.long()

        with torch.set_grad_enabled(train):
            logits = model(ids, mask)
            loss = loss_fn(logits, y)
        if train:
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

        total += loss.item() * len(y)
        seen += len(y)
    return total / max(seen, 1)


@torch.no_grad()
def predict(model, loader, n_classes):
    model.eval()
    preds, golds = [], []
    for batch in loader:
        logits = model(batch["input_ids"].to(C.device()),
                       batch["attention_mask"].to(C.device()))
        if n_classes == 2:
            p = (torch.sigmoid(logits) >= 0.5).long()
        else:
            p = logits.argmax(-1)
        preds += p.cpu().tolist()
        golds += batch["label"].tolist()
    return preds, golds


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True, choices=list(C.MODELS))
    ap.add_argument("--task", required=True, choices=C.TASKS)
    ap.add_argument("--modality", required=True, choices=C.MODALITIES)
    ap.add_argument("--no_bilstm", action="store_true", help="Table 5 ablation")
    ap.add_argument("--seed", type=int, default=C.SEED)
    a = ap.parse_args()

    C.set_all_seeds(a.seed)
    labels = C.LABELS[a.task]
    n_classes = len(labels)
    use_bilstm = not a.no_bilstm

    tokenizer = get_tokenizer(a.model)
    loaders, labels, test_ids = build_loaders(a.task, a.modality, tokenizer)

    model = EncoderBiLSTM(a.model, n_classes, use_bilstm=use_bilstm).to(C.device())
    loss_fn = nn.BCEWithLogitsLoss() if n_classes == 2 else nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(
        [p for p in model.parameters() if p.requires_grad],
        lr=C.HP["lr"], betas=C.HP["adam_betas"])

    tag = f"{a.task}_{a.modality}_{a.model}" + ("" if use_bilstm else "_nobilstm")
    print(f"=== {tag} | seed={a.seed} | trainable params={trainable_parameters(model):,} ===")

    best_val, best_state, patience, history = float("inf"), None, 0, []
    t0 = time.time()
    for epoch in range(1, C.HP["max_epochs"] + 1):
        tr = run_epoch(model, loaders["train"], loss_fn, optimizer, n_classes, True)
        va = run_epoch(model, loaders["val"], loss_fn, optimizer, n_classes, False)
        history.append(dict(epoch=epoch, train_loss=tr, val_loss=va))
        print(f"  epoch {epoch:2d}  train {tr:.4f}  val {va:.4f}")

        if va < best_val - 1e-5:
            best_val, patience = va, 0
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        else:
            patience += 1
            if patience >= C.HP["early_stopping_patience"]:
                print(f"  early stopping at epoch {epoch}")
                break
    train_minutes = (time.time() - t0) / 60.0

    if best_state:
        model.load_state_dict(best_state)

    preds, golds = predict(model, loaders["test"], n_classes)
    pd.DataFrame({
        "id": test_ids,
        "y_true": [labels[i] for i in golds],
        "y_pred": [labels[i] for i in preds],
    }).to_csv(C.PREDS / f"{tag}.csv", index=False)

    (C.LOGS / f"{tag}.json").write_text(json.dumps(dict(
        model=a.model, task=a.task, modality=a.modality, use_bilstm=use_bilstm,
        seed=a.seed, train_minutes=round(train_minutes, 2),
        epochs_run=len(history), best_val_loss=best_val,
        trainable_params=trainable_parameters(model),
        hyperparameters=C.HP, history=history), indent=2))

    print(f"  predictions -> {C.PREDS / (tag + '.csv')}")
    print(f"  training time {train_minutes:.1f} min (report in the Time column)")
    print("  no metrics computed here by design — run evaluate_metrics.py")


if __name__ == "__main__":
    main()
