"""
normalize.py — offline two-stage normalization (Sect. III-C).

    Romanised Kannada-English  --IndicXlit-->  Kannada script  --IndicTrans2-->  English

Run ONCE over the corpus. The output is cached to disk and reused by every
experiment, which is why the efficiency figures in Table 14 measure the
classifier only (Reviewer 3, point 7).

Token-level language identification (Reviewer 3, comprehensiveness query):
genuine English spans in code-mixed input must NOT be transliterated. Each
token is tagged Kannada / English / neutral; only Kannada tokens go to
IndicXlit, the rest are masked, carried through, and restored.

    python -m preprocess.normalize --stage all
"""

import argparse
import re
import sys
from pathlib import Path

import pandas as pd
from tqdm import tqdm

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

XLIT_OUT = C.DATA / "hastika_translit.csv"
NMT_OUT = C.DATA / "hastika_translated.csv"

# Tokens never sent to the transliterator.
NEUTRAL_RE = re.compile(
    r"^(?:@\w+|#\w+|https?://\S+|[\d.,:%/+-]+|[^\w\s]+|[\U0001F300-\U0001FAFF\u2600-\u27BF]+)$"
)
PLACEHOLDER = "\u2581{}\u2581"  # unlikely to appear in user text


# ---------------------------------------------------------------------------
# Stage 0: word-level language identification
# ---------------------------------------------------------------------------
class WordLID:
    """Tag each token as 'kn' (Romanised Kannada), 'en', or 'neutral'.

    Backend order:
      1. an explicit lexicon/model supplied by the user (recommended, and the
         one to cite in the manuscript),
      2. an English-vocabulary fallback so the pipeline is runnable without it.

    IMPORTANT: whichever backend you use, name it and report its accuracy in
    Sect. III-C. Do not describe token-level LID in the paper if you ran the
    pipeline without it.
    """

    def __init__(self, en_vocab_path: Path | None = None):
        self.en_vocab = set()
        if en_vocab_path and en_vocab_path.exists():
            self.en_vocab = {w.strip().lower() for w in en_vocab_path.read_text().splitlines() if w.strip()}
        else:
            try:  # fallback: NLTK's English word list
                from nltk.corpus import words as nltk_words
                self.en_vocab = {w.lower() for w in nltk_words.words()}
            except Exception:
                print("WARNING: no English vocabulary available; every alphabetic token "
                      "will be treated as Kannada. Supply --en_vocab for a real run.")

    def tag(self, token: str) -> str:
        if NEUTRAL_RE.match(token):
            return "neutral"
        if re.search(r"[\u0C80-\u0CFF]", token):     # already Kannada script
            return "neutral"
        if token.lower() in self.en_vocab:
            return "en"
        return "kn"


def mask_non_kannada(text: str, lid: WordLID):
    """Return (string for IndicXlit, {placeholder: original token})."""
    kept, out = {}, []
    for i, tok in enumerate(text.split()):
        if lid.tag(tok) == "kn":
            out.append(tok)
        else:
            ph = PLACEHOLDER.format(i)
            kept[ph] = tok
            out.append(ph)
    return " ".join(out), kept


def restore(text: str, kept: dict) -> str:
    for ph, tok in kept.items():
        text = text.replace(ph, tok)
    return text


# ---------------------------------------------------------------------------
# Stage 1: transliteration
# ---------------------------------------------------------------------------
def transliterate_corpus(en_vocab: Path | None = None):
    from ai4bharat.transliteration import XlitEngine

    df = pd.read_csv(C.RAW_CORPUS)
    lid = WordLID(en_vocab)
    engine = XlitEngine(C.XLIT_LANG, beam_width=C.XLIT_BEAM, rescore=True)

    out = []
    for text in tqdm(df["comment"].astype(str), desc="IndicXlit"):
        masked, kept = mask_non_kannada(text, lid)
        pieces = []
        for tok in masked.split():
            if tok in kept:
                pieces.append(tok)
            else:
                cands = engine.translit_word(tok, topk=1).get(C.XLIT_LANG, [tok])
                pieces.append(cands[0] if cands else tok)
        out.append(restore(" ".join(pieces), kept))

    df["translit"] = out
    df.to_csv(XLIT_OUT, index=False)
    print(f"wrote {XLIT_OUT}  (beam={C.XLIT_BEAM}, LM rescoring on)")


# ---------------------------------------------------------------------------
# Stage 2: translation
# ---------------------------------------------------------------------------
def translate_corpus(batch_size: int = 16):
    import torch
    from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
    from IndicTransToolkit import IndicProcessor

    df = pd.read_csv(XLIT_OUT)
    tok = AutoTokenizer.from_pretrained(C.NMT_MODEL, trust_remote_code=True)
    model = AutoModelForSeq2SeqLM.from_pretrained(C.NMT_MODEL, trust_remote_code=True)
    model.to(C.device()).eval()
    ip = IndicProcessor(inference=True)

    texts = df["translit"].astype(str).tolist()
    out = []
    for i in tqdm(range(0, len(texts), batch_size), desc="IndicTrans2"):
        batch = ip.preprocess_batch(texts[i:i + batch_size],
                                    src_lang=C.NMT_SRC_TAG, tgt_lang=C.NMT_TGT_TAG)
        enc = tok(batch, truncation=True, padding=True, max_length=256, return_tensors="pt").to(C.device())
        with torch.no_grad():
            gen = model.generate(**enc, num_beams=5, max_length=256, num_return_sequences=1)
        dec = tok.batch_decode(gen.detach().cpu(), skip_special_tokens=True)
        out.extend(ip.postprocess_batch(dec, lang=C.NMT_TGT_TAG))

    df["translated"] = out
    df.to_csv(NMT_OUT, index=False)
    print(f"wrote {NMT_OUT}")
    print("\nNormalization is now cached. Training reads these files; the cost of "
          "this script is NOT part of the Table 14 latency figures.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", choices=["translit", "translate", "all"], default="all")
    ap.add_argument("--en_vocab", type=Path, default=None,
                    help="one English word per line; strongly recommended")
    a = ap.parse_args()

    C.set_all_seeds()
    if a.stage in ("translit", "all"):
        transliterate_corpus(a.en_vocab)
    if a.stage in ("translate", "all"):
        translate_corpus()


if __name__ == "__main__":
    main()
