"""
pareto.py — accuracy-cost Pareto frontier and Figure 5 (Sect. V-B, RQ3).

A model is Pareto-optimal in a configuration if no other model achieves both a
strictly higher Macro-F1 and a strictly lower training time. The script also
reports which models reach no frontier in any configuration, which is the claim
that survived the Tables 8-9 correction and now carries more of the argument.

    python -m analysis.pareto
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

PANELS = [("binary", "codemixed", "(a) Binary, code-mixed"),
          ("binary", "translated", "(b) Binary, translated"),
          ("multiclass", "codemixed", "(c) Fine-grained, code-mixed"),
          ("multiclass", "translated", "(d) Fine-grained, translated")]


def frontier(points: dict) -> list:
    """points: {model: (minutes, macro_f1)} -> models not dominated by any other."""
    out = []
    for m, (t, f) in points.items():
        dominated = any(
            (t2 < t and f2 >= f) or (t2 <= t and f2 > f)
            for m2, (t2, f2) in points.items() if m2 != m)
        if not dominated:
            out.append(m)
    return sorted(out, key=lambda m: points[m][0])


def load() -> pd.DataFrame:
    f = C.RESULTS / "tables.csv"
    if not f.exists():
        raise SystemExit("run evaluate_metrics.py first")
    df = pd.read_csv(f)
    df = df[~df["ablation"].astype(bool)]
    if df["train_minutes"].isna().any():
        missing = df[df["train_minutes"].isna()][["task", "modality", "model"]]
        raise SystemExit(f"train_minutes missing for:\n{missing.to_string(index=False)}\n"
                         "The Pareto analysis needs timing from the training logs.")
    # average over seeds if several are present
    return df.groupby(["task", "modality", "model", "group"], as_index=False).agg(
        macro_f1=("macro_f1", "mean"), train_minutes=("train_minutes", "mean"))


def main():
    df = load()
    fig, axes = plt.subplots(2, 2, figsize=(11, 8.5))
    on_frontier, summary = set(), []

    for ax, (task, modality, title) in zip(axes.ravel(), PANELS):
        sub = df[(df.task == task) & (df.modality == modality)]
        pts = {r.model: (r.train_minutes, r.macro_f1) for r in sub.itertuples()}
        if not pts:
            ax.set_visible(False)
            continue

        front = frontier(pts)
        on_frontier |= set(front)
        all_compact = all(C.MODELS[m]["group"] == "compact" for m in front)
        summary.append(dict(configuration=title, frontier=", ".join(front),
                            all_compact=all_compact))

        for m, (t, f) in pts.items():
            compact = C.MODELS[m]["group"] == "compact"
            ax.scatter(t, f, s=130 if m in front else 80,
                       marker="o" if compact else "s",
                       facecolor=("#c9a227" if m in front else ("#4a7ebb" if not compact else "#555555")),
                       edgecolor="black", zorder=3)
            ax.annotate(m, (t, f), textcoords="offset points", xytext=(0, 9),
                        ha="center", fontsize=7.5,
                        fontweight="bold" if m in front else "normal")

        fx = [pts[m][0] for m in front]
        fy = [pts[m][1] for m in front]
        ax.plot(fx, fy, "--", color="#888888", lw=1.2, zorder=2)
        ax.set_xscale("log")
        ax.set_xlabel("Training time (minutes, log scale)", fontsize=9)
        ax.set_ylabel("Macro-F1", fontsize=9)
        ax.set_title(title, fontsize=10, fontweight="bold")
        ax.grid(alpha=0.25, ls=":")

    fig.suptitle("Pareto efficiency: Macro-F1 versus training time across the four configurations",
                 fontsize=11.5, fontweight="bold")
    fig.text(0.5, 0.945, "A model is Pareto-optimal if no other model is both faster and more accurate. "
                         "Circles: distilled compact encoders. Squares: standard-capacity encoders.",
             ha="center", fontsize=8.5, style="italic")
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    out = C.RESULTS / "figure5_pareto.png"
    fig.savefig(out, dpi=300)
    fig.savefig(out.with_suffix(".pdf"))
    print(f"wrote {out}\n")

    s = pd.DataFrame(summary)
    print(s.to_string(index=False))
    s.to_csv(C.RESULTS / "pareto_frontiers.csv", index=False)

    never = sorted(set(df.model) - on_frontier)
    n_all_compact = int(s.all_compact.sum())
    print(f"\ncompact encoders form the ENTIRE frontier in {n_all_compact} of {len(s)} configurations")
    print(f"models reaching NO frontier in any configuration: {', '.join(never) if never else 'none'}")
    print(f"\nSect. V-B must say '{n_all_compact} of {len(s)}' and nothing else. The previous "
          "submission said three of four; that figure came from the erroneous Table 9 "
          "and must not be reused.")
    if never:
        print(f"The claim that {', '.join(never)} reach no frontier anywhere is supported "
              "by the table above and is the strongest surviving result.")


if __name__ == "__main__":
    main()
