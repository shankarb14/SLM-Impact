"""
confusion.py — Figures 6 and 7 plus the quantified error patterns of Sect. VI.

Produces:
  * confusion matrices for the best standard-capacity and best compact encoder
    on fine-grained translated input,
  * the Religion -> Political leakage percentages quoted in Sect. VI,
  * the zero-recall class census ("five of the eight models produce no positive
    predictions for at least one rare class"), computed rather than asserted.

    python -m analysis.confusion
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

LABELS = C.FINE_LABELS


def load_preds(task, modality, model):
    f = C.PREDS / f"{task}_{modality}_{model}.csv"
    if not f.exists():
        raise SystemExit(f"{f} not found")
    return pd.read_csv(f)


def plot_cm(df, model, out_path):
    cm = confusion_matrix(df.y_true, df.y_pred, labels=LABELS)
    fig, ax = plt.subplots(figsize=(6.2, 5.4))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(LABELS)), LABELS, rotation=45, ha="right", fontsize=8)
    ax.set_yticks(range(len(LABELS)), LABELS, fontsize=8)
    ax.set_xlabel("Predicted label", fontsize=9)
    ax.set_ylabel("True label", fontsize=9)
    ax.set_title(f"Confusion matrix — {model}", fontsize=10, fontweight="bold")
    thresh = cm.max() / 2
    for i in range(len(LABELS)):
        for j in range(len(LABELS)):
            ax.text(j, i, cm[i, j], ha="center", va="center", fontsize=8,
                    color="white" if cm[i, j] > thresh else "black")
    fig.colorbar(im, ax=ax, shrink=0.85)
    fig.tight_layout()
    fig.savefig(out_path, dpi=300)
    fig.savefig(out_path.with_suffix(".pdf"))

    acc = cm.trace() / cm.sum()
    print(f"  {model}: n={cm.sum()}, diagonal accuracy={acc:.4f}")
    print(f"  row sums (must equal test supports): "
          f"{dict(zip(LABELS, cm.sum(1).tolist()))}")
    return cm


def leakage(cm, src="Religion", dst="Political"):
    """Share of a class's misclassifications absorbed by another class."""
    i, j = LABELS.index(src), LABELS.index(dst)
    wrong = cm[i].sum() - cm[i, i]
    return (cm[i, j], wrong, 100 * cm[i, j] / wrong if wrong else 0.0)


def zero_recall_census(task="multiclass", modality="codemixed"):
    rows = []
    for model in C.MODELS:
        f = C.PREDS / f"{task}_{modality}_{model}.csv"
        if not f.exists():
            continue
        df = pd.read_csv(f)
        cm = confusion_matrix(df.y_true, df.y_pred, labels=LABELS)
        zeros = [LABELS[i] for i in range(len(LABELS)) if cm[i, i] == 0]
        rows.append(dict(model=model, n_zero_recall_classes=len(zeros),
                         classes="; ".join(zeros) if zeros else "—"))
    return pd.DataFrame(rows)


def main():
    print("Figures 6 and 7 — fine-grained, translated input\n")
    figures = [("BERT", C.RESULTS / "figure6_confusion_bert.png"),
               ("DistilBERT", C.RESULTS / "figure7_confusion_distilbert.png")]

    mats = {}
    for model, out in figures:
        df = load_preds("multiclass", "translated", model)
        mats[model] = plot_cm(df, model, out)
        print(f"  wrote {out}\n")

    print("Religion -> Political leakage (quote these in Sect. VI):")
    for model, cm in mats.items():
        n, wrong, pct = leakage(cm, "Religion", "Political")
        print(f"  {model:12s} {n} of {wrong} misclassified Religion comments ({pct:.0f}%)")
    print("\nreverse direction:")
    for model, cm in mats.items():
        n, wrong, pct = leakage(cm, "Political", "Religion")
        print(f"  {model:12s} {n} of {wrong} misclassified Political comments ({pct:.0f}%)")

    print("\nzero-recall census, fine-grained code-mixed:")
    census = zero_recall_census()
    print(census.to_string(index=False))
    census.to_csv(C.RESULTS / "zero_recall_census.csv", index=False)
    n = int((census.n_zero_recall_classes > 0).sum())
    print(f"\n{n} of {len(census)} models produce zero recall on at least one class.")
    print("Use this computed count in Sect. VI rather than a remembered one.")


if __name__ == "__main__":
    main()
