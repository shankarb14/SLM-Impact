"""
classifier.py — frozen encoder + Bi-LSTM classifier (Sect. III-E).

    tokens -> frozen transformer encoder -> Bi-LSTM -> dropout -> dense(ReLU) -> head

The `use_bilstm=False` path replaces the Bi-LSTM with mean pooling over the
frozen encoder output. That is the ablation of Table 5, so the ablation runs
through exactly the same code as the main experiments rather than a separate
script (which is how the two can drift apart).
"""

import sys
from pathlib import Path

import torch
import torch.nn as nn
from transformers import AutoModel, AutoTokenizer

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C


def masked_mean(hidden: torch.Tensor, mask: torch.Tensor) -> torch.Tensor:
    """Mean over real tokens only — padding must not dilute the representation."""
    m = mask.unsqueeze(-1).float()
    return (hidden * m).sum(1) / m.sum(1).clamp(min=1e-9)


class EncoderBiLSTM(nn.Module):
    def __init__(self, model_key: str, n_classes: int, use_bilstm: bool = True, hp: dict | None = None):
        super().__init__()
        hp = hp or C.HP
        spec = C.MODELS[model_key]

        self.encoder = AutoModel.from_pretrained(spec["hf"])
        if hp["freeze_encoder"]:
            for p in self.encoder.parameters():
                p.requires_grad = False
            self.encoder.eval()

        d = self.encoder.config.hidden_size
        self.use_bilstm = use_bilstm

        if use_bilstm:
            self.bilstm = nn.LSTM(d, hp["bilstm_hidden"], batch_first=True,
                                  bidirectional=True, num_layers=1)
            feat = hp["bilstm_hidden"] * 2
        else:
            self.bilstm = None
            feat = d

        self.dropout = nn.Dropout(hp["dropout"])
        self.dense = nn.Linear(feat, hp["dense_hidden"])
        self.act = nn.ReLU()
        # Binary uses a single logit with BCEWithLogits; multi-class uses C logits
        # with CrossEntropy. Both losses are numerically stable versions of the
        # sigmoid / softmax formulations described in Sect. III-A.
        self.head = nn.Linear(hp["dense_hidden"], 1 if n_classes == 2 else n_classes)
        self.n_classes = n_classes

    def forward(self, input_ids, attention_mask):
        ctx = torch.no_grad() if not self.encoder.training else torch.enable_grad()
        with ctx:
            hidden = self.encoder(input_ids=input_ids,
                                  attention_mask=attention_mask).last_hidden_state

        if self.use_bilstm:
            lengths = attention_mask.sum(1).cpu()
            packed = nn.utils.rnn.pack_padded_sequence(
                hidden, lengths, batch_first=True, enforce_sorted=False)
            _, (h_n, _) = self.bilstm(packed)
            feat = torch.cat([h_n[0], h_n[1]], dim=-1)   # final fwd + bwd states
        else:
            feat = masked_mean(hidden, attention_mask)

        z = self.act(self.dense(self.dropout(feat)))
        return self.head(z).squeeze(-1) if self.n_classes == 2 else self.head(z)


def get_tokenizer(model_key: str):
    return AutoTokenizer.from_pretrained(C.MODELS[model_key]["hf"])


def trainable_parameters(model: nn.Module) -> int:
    return sum(p.numel() for p in model.parameters() if p.requires_grad)
