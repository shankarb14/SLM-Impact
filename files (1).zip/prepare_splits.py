"""
prepare_splits.py — build and release the train/val/test index files.

Addresses Reviewer 3, point 4: the binary and fine-grained tasks operate on
different subsets of HASTIKA and must be described separately.

    binary       : all 8058 comments, stratified on {Hate, Non-Hate}
    multiclass   : the 3950 hateful comments only, stratified on the six
                   thematic classes (they are defined within the hate class)

Both use a 70:10:20 ratio under SEED. Only comment IDs are written, so the
files can be released without redistributing the corpus.

    python -m data.prepare_splits
"""

import sys
from pathlib import Path

import pandas as pd
from sklearn.model_selection import train_test_split

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C


def load_corpus() -> pd.DataFrame:
    if not C.RAW_CORPUS.exists():
        raise FileNotFoundError(
            f"{C.RAW_CORPUS} not found. Obtain HASTIKA from Kavatagi & Rachh (2025), "
            "doi:10.1007/s10579-025-09836-1, and save it with columns "
            "id,comment,binary_label,fine_label."
        )
    df = pd.read_csv(C.RAW_CORPUS)
    for col in ("id", "comment", "binary_label", "fine_label"):
        if col not in df.columns:
            raise ValueError(f"corpus is missing required column '{col}'")
    return df


def assert_composition(df: pd.DataFrame) -> None:
    """Fail loudly if the corpus does not match Table 2 of the manuscript."""
    if len(df) != C.EXPECTED_TOTAL:
        raise AssertionError(f"expected {C.EXPECTED_TOTAL} comments, found {len(df)}")

    got_bin = df["binary_label"].value_counts().to_dict()
    if got_bin != C.EXPECTED_BINARY_COUNTS:
        raise AssertionError(f"binary counts {got_bin} != Table 2 {C.EXPECTED_BINARY_COUNTS}")

    hate = df[df["binary_label"] == "Hate"]
    got_fine = hate["fine_label"].value_counts().to_dict()
    if got_fine != C.EXPECTED_FINE_COUNTS:
        raise AssertionError(f"fine-grained counts {got_fine} != Table 2 {C.EXPECTED_FINE_COUNTS}")

    n_fine_labelled = df["fine_label"].notna().sum()
    if n_fine_labelled != len(hate):
        raise AssertionError(
            f"{n_fine_labelled} comments carry a fine label but only {len(hate)} are hateful; "
            "the six thematic classes must be defined within the hate class only"
        )
    print(f"corpus composition matches Table 2 ({len(df)} comments)")


def three_way_split(ids, labels, seed=C.SEED):
    """70:10:20 stratified split. Two calls, so val and test are both stratified."""
    r = C.SPLIT_RATIOS
    train_ids, hold_ids, _, hold_y = train_test_split(
        ids, labels, test_size=r["val"] + r["test"], stratify=labels, random_state=seed
    )
    val_frac = r["val"] / (r["val"] + r["test"])
    val_ids, test_ids = train_test_split(
        hold_ids, test_size=1 - val_frac, stratify=hold_y, random_state=seed
    )
    return sorted(train_ids), sorted(val_ids), sorted(test_ids)


def write_split(task: str, train_ids, val_ids, test_ids, df, label_col):
    out = C.SPLITS / task
    out.mkdir(parents=True, exist_ok=True)
    for name, ids in (("train", train_ids), ("val", val_ids), ("test", test_ids)):
        pd.DataFrame({"id": ids}).to_csv(out / f"{name}.csv", index=False)

    by_id = df.set_index("id")[label_col]
    rows = []
    for name, ids in (("train", train_ids), ("val", val_ids), ("test", test_ids)):
        counts = by_id.loc[ids].value_counts().to_dict()
        rows.append(dict(split=name, n=len(ids), **counts))
    summary = pd.DataFrame(rows)
    summary.to_csv(out / "summary.csv", index=False)
    print(f"\n[{task}]")
    print(summary.to_string(index=False))
    return summary


def main():
    C.set_all_seeds()
    df = load_corpus()
    assert_composition(df)

    # --- binary: the whole corpus -------------------------------------------
    tr, va, te = three_way_split(df["id"].tolist(), df["binary_label"].tolist())
    write_split("binary", tr, va, te, df, "binary_label")

    # --- fine-grained: hateful comments only --------------------------------
    hate = df[df["binary_label"] == "Hate"]
    tr, va, te = three_way_split(hate["id"].tolist(), hate["fine_label"].tolist())
    fine_summary = write_split("multiclass", tr, va, te, hate, "fine_label")

    # The fine-grained test partition must reproduce the per-class supports
    # quoted in Sect. VI; this is the internal check the manuscript refers to.
    test_row = fine_summary[fine_summary.split == "test"].iloc[0].to_dict()
    print("\nfine-grained test supports (report these in Sect. VI):")
    for lab in C.FINE_LABELS:
        print(f"  {lab:15s} {int(test_row.get(lab, 0))}")
    print(f"  {'TOTAL':15s} {int(test_row['n'])}")
    print(f"\nindex files written to {C.SPLITS}")


if __name__ == "__main__":
    main()
