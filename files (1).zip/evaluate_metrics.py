"""
evaluate_metrics.py — THE only place metrics are computed.

Every number in Tables 5-13 comes from this script, applied to the stored
prediction files. Nothing is transferred into the manuscript by hand.

Two assertions run on every row, and they are the ones that would have caught
the Tables 8-9 defect:

    (1) reported Macro-F1 == unweighted mean of the per-class F1 printed
        in the same row  (manuscript Eq. 13)
    (2) reported Accuracy == confusion-matrix diagonal / total

If multiple seeds are present, mean +/- SD is reported per configuration.
With one seed it reports point estimates and says so, which is what the
manuscript currently claims.

    python evaluate_metrics.py
    python evaluate_metrics.py --latex
"""

import argparse
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_recall_fscore_support)

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C

STEM = re.compile(r"^(?P<task>binary|multiclass)_(?P<modality>codemixed|translated)_"
                  r"(?P<model>[A-Za-z0-9.\-]+?)(?P<abl>_nobilstm)?(?:_seed(?P<seed>\d+))?$")


def evaluate_one(y_true, y_pred, labels):
    p, r, f, s = precision_recall_fscore_support(y_true, y_pred, labels=labels, zero_division=0)
    macro = f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)
    acc = accuracy_score(y_true, y_pred)
    cm = confusion_matrix(y_true, y_pred, labels=labels)

    # ---- assertion 1: Macro-F1 is the unweighted mean of per-class F1 --------
    manual = float(np.mean(f))
    if abs(manual - macro) > 1e-9:
        raise AssertionError(
            f"Macro-F1 inconsistent: sklearn {macro:.6f} vs mean of per-class F1 {manual:.6f}")

    # ---- assertion 2: accuracy is the confusion diagonal --------------------
    implied = cm.trace() / cm.sum()
    if abs(implied - acc) > 1e-9:
        raise AssertionError(
            f"Accuracy inconsistent: reported {acc:.6f} vs confusion diagonal {implied:.6f}")

    return dict(
        macro_f1=macro, accuracy=acc, n=int(cm.sum()),
        per_class={lab: dict(P=float(p[i]), R=float(r[i]), F1=float(f[i]), n=int(s[i]))
                   for i, lab in enumerate(labels)},
        confusion=cm.tolist(), labels=labels,
    )


def train_minutes(tag: str) -> float | None:
    f = C.LOGS / f"{tag}.json"
    if f.exists():
        return json.loads(f.read_text()).get("train_minutes")
    return None


def collect():
    rows, by_config = [], defaultdict(list)
    files = sorted(C.PREDS.glob("*.csv"))
    if not files:
        raise SystemExit(f"no prediction files in {C.PREDS} — run run_all.py first")

    for path in files:
        m = STEM.match(path.stem)
        if not m:
            print(f"  skipping unrecognised file name: {path.name}")
            continue
        g = m.groupdict()
        task, modality, model = g["task"], g["modality"], g["model"]
        ablation = bool(g["abl"])
        seed = int(g["seed"]) if g["seed"] else C.SEED

        df = pd.read_csv(path)
        res = evaluate_one(df["y_true"].tolist(), df["y_pred"].tolist(), C.LABELS[task])

        row = dict(task=task, modality=modality, model=model,
                   group=C.MODELS[model]["group"], ablation=ablation, seed=seed,
                   macro_f1=round(res["macro_f1"], 4), accuracy=round(res["accuracy"], 4),
                   n_test=res["n"], train_minutes=train_minutes(path.stem))
        for lab, v in res["per_class"].items():
            row[f"P_{lab}"] = round(v["P"], 4)
            row[f"R_{lab}"] = round(v["R"], 4)
            row[f"F1_{lab}"] = round(v["F1"], 4)
            row[f"n_{lab}"] = v["n"]
        rows.append(row)
        by_config[(task, modality, model, ablation)].append(res)

        flag = " [ablation]" if ablation else ""
        print(f"  {path.stem:48s} Macro-F1={res['macro_f1']:.4f}  Acc={res['accuracy']:.4f}  "
              f"n={res['n']}  OK{flag}")

    return pd.DataFrame(rows), by_config


def seed_summary(by_config) -> pd.DataFrame:
    out = []
    for (task, modality, model, abl), runs in sorted(by_config.items()):
        f1s = [r["macro_f1"] for r in runs]
        accs = [r["accuracy"] for r in runs]
        out.append(dict(
            task=task, modality=modality, model=model, ablation=abl, n_seeds=len(runs),
            macro_f1_mean=round(float(np.mean(f1s)), 4),
            macro_f1_sd=round(float(np.std(f1s, ddof=1)), 4) if len(f1s) > 1 else None,
            accuracy_mean=round(float(np.mean(accs)), 4),
            accuracy_sd=round(float(np.std(accs, ddof=1)), 4) if len(accs) > 1 else None,
        ))
    return pd.DataFrame(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--latex", action="store_true", help="also emit LaTeX via tables.make_tables")
    a = ap.parse_args()

    print(f"reading predictions from {C.PREDS}\n")
    df, by_config = collect()

    out = C.RESULTS / "tables.csv"
    df.to_csv(out, index=False)
    summary = seed_summary(by_config)
    summary.to_csv(C.RESULTS / "seed_summary.csv", index=False)

    n_seeds = df.groupby(["task", "modality", "model", "ablation"]).seed.nunique().max()
    print(f"\nwrote {len(df)} rows to {out}")
    print(f"wrote per-configuration summary to {C.RESULTS / 'seed_summary.csv'}")

    print("\n" + "=" * 72)
    if n_seeds == 1:
        print("SINGLE RUN PER CONFIGURATION.")
        print("Report point estimates. Do NOT claim averaging over runs, standard")
        print("deviations, or significance tests. Differences of ~0.01 Macro-F1 or")
        print("less are not interpretable — see Sect. III-G and Sect. VII.")
    else:
        print(f"{n_seeds} SEEDS PER CONFIGURATION.")
        print("Report mean +/- SD from seed_summary.csv, state the seeds used, and")
        print("run analysis/significance.py for paired tests before making any")
        print("claim about a narrow margin.")
    print("=" * 72)
    print("\nPaste values into the manuscript from tables.csv only. Never retype them.")

    if a.latex:
        from tables import make_tables
        make_tables.main()


if __name__ == "__main__":
    main()
