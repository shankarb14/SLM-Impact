"""
make_tables.py — emit IEEE-style LaTeX for Tables 5-14 straight from tables.csv.

The point of this script is that no aggregate value is ever retyped. Copy the
generated .tex into the manuscript, or \\input it. If a value in the paper
differs from tables.csv, the paper is wrong.

    python -m tables.make_tables
"""

import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

OUT = C.RESULTS / "latex"
OUT.mkdir(parents=True, exist_ok=True)

SHORT = {"Gender": "Gen", "Political": "Pol", "Religion": "Rel",
         "Geo-political": "Geo", "Violence": "Viol", "Others": "Oth"}
GROUP_NAME = {"standard": "standard-capacity encoders", "compact": "distilled compact encoders"}


def load():
    f = C.RESULTS / "tables.csv"
    if not f.exists():
        raise SystemExit("run evaluate_metrics.py first")
    return pd.read_csv(f)


def bold_max(values, fmt="{:.4f}"):
    hi = max(values)
    return [(r"\textbf{" + fmt.format(v) + "}") if v == hi else fmt.format(v) for v in values]


def binary_table(df, modality, group, number, caption):
    sub = df[(df.task == "binary") & (df.modality == modality) &
             (df.group == group) & (~df.ablation.astype(bool))]
    order = C.STANDARD if group == "standard" else C.COMPACT
    sub = sub.set_index("model").reindex([m for m in order if m in set(sub.model)])
    if sub.empty:
        return None

    need = ["P_Hate", "R_Hate", "P_Non-Hate", "R_Non-Hate"]
    absent = [c for c in need if c not in sub.columns or sub[c].isna().all()]
    if absent:
        print(f"  Table {number}: skipped — tables.csv lacks {absent}. "
              "Re-run evaluate_metrics.py over the binary prediction files.")
        return None

    f1s = bold_max(sub.macro_f1.tolist())
    accs = bold_max(sub.accuracy.tolist())

    L = [r"\begin{table}[!t]", r"\centering",
         f"\\caption{{{caption}}}", f"\\label{{tab:{number}}}",
         r"\begin{tabular}{lcccccccc}", r"\hline",
         r"Model & $P_{\mathrm{hate}}$ & $R_{\mathrm{hate}}$ & $P_{\mathrm{NH}}$ & "
         r"$R_{\mathrm{NH}}$ & Macro-F1 & Accuracy & Time \\", r"\hline"]
    for i, (m, r) in enumerate(sub.iterrows()):
        t = f"{r.train_minutes:.1f} min" if pd.notna(r.train_minutes) else "--"
        L.append(f"{m} & {r['P_Hate']:.4f} & {r['R_Hate']:.4f} & {r['P_Non-Hate']:.4f} & "
                 f"{r['R_Non-Hate']:.4f} & {f1s[i]} & {accs[i]} & {t} \\\\")
    L += [r"\hline", r"\end{tabular}",
          r"\begin{tablenotes}\footnotesize\item Single run per configuration; "
          r"point estimates without variance (Sect.~III-G).\end{tablenotes}",
          r"\end{table}"]
    return "\n".join(L)


def fine_table(df, modality, group, number, caption):
    sub = df[(df.task == "multiclass") & (df.modality == modality) &
             (df.group == group) & (~df.ablation.astype(bool))]
    order = C.STANDARD if group == "standard" else C.COMPACT
    sub = sub.set_index("model").reindex([m for m in order if m in set(sub.model)])
    if sub.empty:
        return None

    f1s = bold_max(sub.macro_f1.tolist())
    accs = bold_max(sub.accuracy.tolist())
    heads = " & ".join(SHORT[l] for l in C.FINE_LABELS)

    L = [r"\begin{table*}[!t]", r"\centering",
         f"\\caption{{{caption}}}", f"\\label{{tab:{number}}}",
         r"\begin{tabular}{l" + "c" * 6 + "ccc}", r"\hline",
         f"Model & {heads} & Macro-F1 & Acc & Time \\\\", r"\hline"]
    for i, (m, r) in enumerate(sub.iterrows()):
        cells = " & ".join(f"{r[f'P_{l}']:.2f}/{r[f'R_{l}']:.2f}" for l in C.FINE_LABELS)
        t = f"{r.train_minutes:.1f}m" if pd.notna(r.train_minutes) else "--"
        L.append(f"{m} & {cells} & {f1s[i]} & {accs[i]} & {t} \\\\")
    L += [r"\hline", r"\end{tabular}",
          r"\begin{tablenotes}\footnotesize\item Per-class entries are precision/recall. "
          r"Macro-F1 is the unweighted mean of the six per-class F1 values implied by "
          r"these figures (Eq.~13); this is verified programmatically."
          r"\end{tablenotes}", r"\end{table*}"]
    return "\n".join(L)


def ablation_table(df):
    abl = df[df.ablation.astype(bool)]
    main = df[~df.ablation.astype(bool)]
    if abl.empty:
        print("  Table 5: no ablation runs found — skipped")
        return None

    L = [r"\begin{table}[!t]", r"\centering",
         r"\caption{Ablation of the Bi-LSTM layer (Macro-F1). Values without the "
         r"Bi-LSTM use mean pooling over the frozen encoder output.}", r"\label{tab:5}",
         r"\begin{tabular}{llccc}", r"\hline",
         r"Model & Configuration & With Bi-LSTM & Without Bi-LSTM & $\Delta$ \\", r"\hline"]
    for _, r in abl.iterrows():
        w = main[(main.model == r.model) & (main.task == r.task) & (main.modality == r.modality)]
        if w.empty:
            continue
        with_f1 = float(w.macro_f1.iloc[0])
        label = f"{'Binary' if r.task == 'binary' else 'Multi-class'}, " \
                f"{'code-mixed' if r.modality == 'codemixed' else 'translated'}"
        L.append(f"{r.model} & {label} & {with_f1:.4f} & {r.macro_f1:.4f} & "
                 f"{r.macro_f1 - with_f1:+.4f} \\\\")
    L += [r"\hline", r"\end{tabular}", r"\end{table}"]
    return "\n".join(L)


def efficiency_table():
    f = C.RESULTS / "table14_efficiency.csv"
    if not f.exists():
        print("  Table 14: run analysis/efficiency.py first — skipped")
        return None
    df = pd.read_csv(f).set_index("model").reindex(list(C.MODELS))
    L = [r"\begin{table}[!t]", r"\centering",
         r"\caption{Extended efficiency metrics. Classifier stage only; the "
         r"normalization pipeline is executed offline (Sect.~III-C).}", r"\label{tab:14}",
         r"\begin{tabular}{lccc}", r"\hline",
         r"Model & Peak GPU memory (GB) & Latency (ms/comment) & Throughput (comments/s) \\",
         r"\hline"]
    for m, r in df.iterrows():
        L.append(f"{m} & {r.peak_gpu_gb:.1f} & {r.latency_ms:.1f} & {int(r.throughput_per_s)} \\\\")
    L += [r"\hline", r"\end{tabular}", r"\end{table}"]
    return "\n".join(L)


def main():
    df = load()
    specs = [
        ("table5_ablation", ablation_table(df)),
        ("table6", binary_table(df, "codemixed", "standard", 6,
            f"Binary classification on code-mixed text: {GROUP_NAME['standard']}.")),
        ("table7", binary_table(df, "codemixed", "compact", 7,
            f"Binary classification on code-mixed text: {GROUP_NAME['compact']}.")),
        ("table8", fine_table(df, "codemixed", "standard", 8,
            f"Fine-grained classification on code-mixed text: {GROUP_NAME['standard']}.")),
        ("table9", fine_table(df, "codemixed", "compact", 9,
            f"Fine-grained classification on code-mixed text: {GROUP_NAME['compact']}.")),
        ("table10", binary_table(df, "translated", "standard", 10,
            f"Binary classification on translated text: {GROUP_NAME['standard']}.")),
        ("table11", binary_table(df, "translated", "compact", 11,
            f"Binary classification on translated text: {GROUP_NAME['compact']}.")),
        ("table12", fine_table(df, "translated", "standard", 12,
            f"Fine-grained classification on translated text: {GROUP_NAME['standard']}.")),
        ("table13", fine_table(df, "translated", "compact", 13,
            f"Fine-grained classification on translated text: {GROUP_NAME['compact']}.")),
        ("table14_efficiency", efficiency_table()),
    ]

    written = []
    for name, tex in specs:
        if tex:
            (OUT / f"{name}.tex").write_text(tex + "\n")
            written.append(name)
            print(f"  wrote {name}.tex")

    (OUT / "all_tables.tex").write_text(
        "\n".join(f"\\input{{latex/{n}}}" for n in written) + "\n")
    print(f"\n{len(written)} tables in {OUT}")
    print("\\input{latex/all_tables} to include them all.")
    print("\nDo not edit these .tex files by hand. If a value is wrong, the prediction")
    print("files are wrong — fix those and regenerate.")


if __name__ == "__main__":
    main()
