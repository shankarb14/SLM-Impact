"""
dataset.py — assemble a task x modality dataset from the released split files.

The split files contain IDs only, so the same partition is guaranteed across
modalities: a comment in the binary test set is in the binary test set whether
the input is code-mixed or translated. That is what makes the 2x2 comparison
valid (Sect. III-F).
"""

import sys
from pathlib import Path

import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

TEXT_COLUMN = {"codemixed": "comment", "translated": "translated"}
LABEL_COLUMN = {"binary": "binary_label", "multiclass": "fine_label"}


def load_normalized() -> pd.DataFrame:
    src = C.DATA / "hastika_translated.csv"
    if not src.exists():
        raise FileNotFoundError(
            f"{src} not found — run `python -m preprocess.normalize --stage all` first. "
            "Normalization is an offline step (Sect. III-C)."
        )
    return pd.read_csv(src)


def load_ids(task: str, split: str) -> list:
    f = C.SPLITS / task / f"{split}.csv"
    if not f.exists():
        raise FileNotFoundError(f"{f} not found — run `python -m data.prepare_splits` first.")
    return pd.read_csv(f)["id"].tolist()


class CommentDataset(Dataset):
    def __init__(self, texts, labels, tokenizer, max_len):
        self.enc = tokenizer(list(texts), truncation=True, padding="max_length",
                             max_length=max_len, return_tensors="pt")
        self.labels = torch.tensor(labels)

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, i):
        return {"input_ids": self.enc["input_ids"][i],
                "attention_mask": self.enc["attention_mask"][i],
                "label": self.labels[i]}


def build_loaders(task: str, modality: str, tokenizer, batch_size: int | None = None):
    """Return (loaders, label_list, test_ids). test_ids let predictions be traced
    back to individual comments, which the error analysis and Table 4b need."""
    df = load_normalized().set_index("id")
    labels = C.LABELS[task]
    l2i = {l: i for i, l in enumerate(labels)}
    text_col, label_col = TEXT_COLUMN[modality], LABEL_COLUMN[task]
    bs = batch_size or C.HP["batch_size"]

    loaders, test_ids = {}, None
    for split in ("train", "val", "test"):
        ids = load_ids(task, split)
        sub = df.loc[ids]
        ds = CommentDataset(sub[text_col].astype(str).tolist(),
                            [l2i[v] for v in sub[label_col]],
                            tokenizer, C.HP["max_seq_len"])
        loaders[split] = DataLoader(ds, batch_size=bs, shuffle=(split == "train"),
                                    num_workers=2, drop_last=False)
        if split == "test":
            test_ids = ids
    return loaders, labels, test_ids
