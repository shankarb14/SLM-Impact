"""
efficiency.py — Table 14: peak GPU memory, single-comment latency, batched
throughput (Reviewer 3, point 7).

Two things this script makes explicit, both of which the manuscript now states:

  1. These are CLASSIFIER-STAGE figures. Normalization runs offline
     (preprocess/normalize.py), so its cost is not included.
  2. With --include_normalization the script also measures the IndicXlit +
     IndicTrans2 cost per comment, so the paper can state honestly what a
     request-time normalizing deployment would cost. Run it once and quote the
     number in Sect. VII rather than leaving the objection open.

    python -m analysis.efficiency
    python -m analysis.efficiency --include_normalization
"""

import argparse
import sys
import time
from pathlib import Path

import pandas as pd
import torch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C
from models.classifier import EncoderBiLSTM, get_tokenizer

WARMUP, N_LATENCY, BATCH = 10, 200, 32
SAMPLE = "Intaha loafergala karanadindale samaja nashavaguttide"


def measure(model_key: str, n_classes: int = 2) -> dict:
    C.set_all_seeds()
    tok = get_tokenizer(model_key)
    model = EncoderBiLSTM(model_key, n_classes).to(C.device()).eval()

    def encode(texts):
        return tok(texts, return_tensors="pt", padding="max_length",
                   truncation=True, max_length=C.HP["max_seq_len"]).to(C.device())

    one = encode([SAMPLE])
    with torch.no_grad():
        for _ in range(WARMUP):
            model(one["input_ids"], one["attention_mask"])

    if torch.cuda.is_available():
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()

    # ---- single-comment latency -------------------------------------------
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(N_LATENCY):
            model(one["input_ids"], one["attention_mask"])
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    latency_ms = (time.perf_counter() - t0) / N_LATENCY * 1000

    # ---- batched throughput ------------------------------------------------
    batch = encode([SAMPLE] * BATCH)
    with torch.no_grad():
        for _ in range(3):
            model(batch["input_ids"], batch["attention_mask"])
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    n_batches = 20
    with torch.no_grad():
        for _ in range(n_batches):
            model(batch["input_ids"], batch["attention_mask"])
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    throughput = (BATCH * n_batches) / (time.perf_counter() - t0)

    peak_gb = (torch.cuda.max_memory_allocated() / 1024 ** 3) if torch.cuda.is_available() else float("nan")

    del model
    if torch.cuda.is_available():
        torch.cuda.empty_cache()

    return dict(model=model_key, group=C.MODELS[model_key]["group"],
                params_m=C.MODELS[model_key]["params_m"],
                peak_gpu_gb=round(peak_gb, 2),
                latency_ms=round(latency_ms, 1),
                throughput_per_s=int(round(throughput)))


def normalization_cost(n: int = 50) -> None:
    """Measure the offline pipeline so Sect. VII can state the real cost."""
    print("\nNormalization cost (NOT part of Table 14)")
    print("-" * 60)
    try:
        from ai4bharat.transliteration import XlitEngine
        from transformers import AutoModelForSeq2SeqLM, AutoTokenizer
        from IndicTransToolkit import IndicProcessor
    except ImportError as e:
        print(f"  dependencies unavailable ({e}); skipping.")
        return

    engine = XlitEngine(C.XLIT_LANG, beam_width=C.XLIT_BEAM, rescore=True)
    t0 = time.perf_counter()
    for _ in range(n):
        for w in SAMPLE.split():
            engine.translit_word(w, topk=1)
    xlit_ms = (time.perf_counter() - t0) / n * 1000

    tok = AutoTokenizer.from_pretrained(C.NMT_MODEL, trust_remote_code=True)
    nmt = AutoModelForSeq2SeqLM.from_pretrained(C.NMT_MODEL, trust_remote_code=True).to(C.device()).eval()
    ip = IndicProcessor(inference=True)
    batch = ip.preprocess_batch([SAMPLE], src_lang=C.NMT_SRC_TAG, tgt_lang=C.NMT_TGT_TAG)
    enc = tok(batch, return_tensors="pt", padding=True, truncation=True, max_length=256).to(C.device())
    with torch.no_grad():
        for _ in range(3):
            nmt.generate(**enc, num_beams=5, max_length=256)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    with torch.no_grad():
        for _ in range(n):
            nmt.generate(**enc, num_beams=5, max_length=256)
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    nmt_ms = (time.perf_counter() - t0) / n * 1000

    print(f"  IndicXlit    : {xlit_ms:7.1f} ms/comment")
    print(f"  IndicTrans2  : {nmt_ms:7.1f} ms/comment  (~1.1B parameters)")
    print(f"  TOTAL        : {xlit_ms + nmt_ms:7.1f} ms/comment")
    print("\n  Quote this in Sect. VII: a request-time normalizing deployment carries")
    print("  this cost per comment on top of the classifier, which is why the")
    print("  efficiency claims are scoped to the classifier stage.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--include_normalization", action="store_true")
    a = ap.parse_args()

    if not torch.cuda.is_available():
        print("WARNING: no GPU detected. Latency and memory figures will not match the "
              "NVIDIA T4 numbers reported in the manuscript.\n")

    rows = [measure(m) for m in C.MODELS]
    for r in rows:
        print(f"  {r['model']:12s} mem={r['peak_gpu_gb']:>5} GB  "
              f"lat={r['latency_ms']:>6} ms  thr={r['throughput_per_s']:>5}/s")

    df = pd.DataFrame(rows)
    out = C.RESULTS / "table14_efficiency.csv"
    df.to_csv(out, index=False)
    print(f"\nwrote {out}")
    print("Table 14 caption must read: classifier stage only; normalization is offline.")

    if a.include_normalization:
        normalization_cost()


if __name__ == "__main__":
    main()
