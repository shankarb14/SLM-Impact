"""
translation_quality.py — Sect. III-D and the new Table 4b.

Part 1: multi-reference BLEU and chrF++ over the 200-comment gold subset.
        Multi-reference so a hypothesis matching either annotator is credited;
        single-reference scores per annotator are also printed, since the
        reviewer asked how multiple references are aggregated.

Part 2: adequacy and preservation agreement. Cohen's kappa is reported for the
        BINARY preserved / not-preserved judgement; quadratic-weighted kappa is
        reported for the ordinal 1-5 adequacy scale. The manuscript must say
        which is which.

Part 3: THE NEW ANALYSIS (Reviewer 3, point 6). Classification accuracy on the
        meaning-preserved subset versus the meaning-degraded subset, using
        predictions already on disk. This converts a qualitative association
        into a measurement.

Input files
-----------
artifacts/data/tq_subset.csv
    id, comment, translated, ref_a, ref_b,
    adequacy_a, adequacy_b,            # 1-5 integers
    preserved_a, preserved_b           # 1 = hateful reading preserved, 0 = lost

    python -m preprocess.translation_quality
"""

import sys
from pathlib import Path

import pandas as pd
from sklearn.metrics import cohen_kappa_score

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

SUBSET = C.DATA / "tq_subset.csv"
REQUIRED = ["id", "translated", "ref_a", "ref_b",
            "adequacy_a", "adequacy_b", "preserved_a", "preserved_b"]


def load_subset() -> pd.DataFrame:
    if not SUBSET.exists():
        raise SystemExit(
            f"{SUBSET} not found.\n"
            f"Build it by sampling {C.TQ_SUBSET_SIZE} comments stratified over the six\n"
            "fine-grained classes, then adding both annotators' reference translations,\n"
            "adequacy ratings, and preservation flags. Columns: " + ", ".join(REQUIRED))
    df = pd.read_csv(SUBSET)
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise SystemExit(f"{SUBSET} is missing columns: {missing}")
    if len(df) != C.TQ_SUBSET_SIZE:
        print(f"WARNING: subset has {len(df)} rows, manuscript states {C.TQ_SUBSET_SIZE}")
    return df


# ---------------------------------------------------------------------------
def surface_metrics(df):
    import sacrebleu

    hyps = df["translated"].astype(str).tolist()
    refs_a = df["ref_a"].astype(str).tolist()
    refs_b = df["ref_b"].astype(str).tolist()

    print("Surface-overlap metrics")
    print("-" * 60)
    multi = dict(
        bleu=sacrebleu.corpus_bleu(hyps, [refs_a, refs_b]).score,
        chrf=sacrebleu.corpus_chrf(hyps, [refs_a, refs_b], word_order=2).score,
    )
    print(f"  multi-reference (both annotators): BLEU = {multi['bleu']:.1f}  "
          f"chrF++ = {multi['chrf']:.1f}   <-- report these in Sect. III-D")
    for name, refs in (("annotator A", refs_a), ("annotator B", refs_b)):
        b = sacrebleu.corpus_bleu(hyps, [refs]).score
        c = sacrebleu.corpus_chrf(hyps, [refs], word_order=2).score
        print(f"  single-reference, {name:12s}: BLEU = {b:.1f}  chrF++ = {c:.1f}")
    print("  (single-reference scores go in the supplementary material)")
    return multi


def agreement(df):
    print("\nHuman judgements")
    print("-" * 60)
    mean_adeq = pd.concat([df.adequacy_a, df.adequacy_b]).mean()
    print(f"  mean adequacy (1-5, both annotators pooled): {mean_adeq:.2f}")

    k_pres = cohen_kappa_score(df.preserved_a, df.preserved_b)
    k_adeq = cohen_kappa_score(df.adequacy_a, df.adequacy_b, weights="quadratic")
    print(f"  Cohen's kappa, preserved/not-preserved (binary): {k_pres:.2f}")
    print(f"  quadratic-weighted kappa, adequacy (ordinal)   : {k_adeq:.2f}")
    print("  Sect. III-D must state which kappa refers to which judgement.")

    both = (df.preserved_a.astype(bool) & df.preserved_b.astype(bool))
    print(f"\n  hate-bearing content preserved (both annotators agree): "
          f"{both.sum()} of {len(df)} ({100 * both.mean():.0f}%)")
    return dict(mean_adequacy=mean_adeq, kappa_preserved=k_pres, kappa_adequacy=k_adeq)


# ---------------------------------------------------------------------------
def downstream_impact(df, models=("BERT", "DistilBERT")):
    """Table 4b: does translation error propagate to classification error?"""
    print("\nTable 4b — downstream effect of translation error")
    print("-" * 60)

    # A comment counts as preserved only if both annotators agreed it was.
    df = df.copy()
    df["preserved"] = (df.preserved_a.astype(bool) & df.preserved_b.astype(bool))

    rows = []
    for model in models:
        f = C.PREDS / f"multiclass_translated_{model}.csv"
        if not f.exists():
            print(f"  skipping {model}: {f.name} not found")
            continue
        preds = pd.read_csv(f)
        merged = preds.merge(df[["id", "preserved"]], on="id", how="inner")
        if merged.empty:
            print(f"  skipping {model}: no subset IDs appear in the test partition")
            continue

        merged["correct"] = merged.y_true == merged.y_pred
        g = merged.groupby("preserved")["correct"].agg(["mean", "size"])
        acc_p = g.loc[True, "mean"] if True in g.index else float("nan")
        n_p = int(g.loc[True, "size"]) if True in g.index else 0
        acc_d = g.loc[False, "mean"] if False in g.index else float("nan")
        n_d = int(g.loc[False, "size"]) if False in g.index else 0

        rows.append(dict(model=model, setting="Fine-grained, translated",
                         acc_preserved=round(float(acc_p), 4), n_preserved=n_p,
                         acc_degraded=round(float(acc_d), 4), n_degraded=n_d,
                         difference=round(float(acc_p - acc_d), 4)))
        print(f"  {model:12s} preserved n={n_p:3d} acc={acc_p:.4f} | "
              f"degraded n={n_d:3d} acc={acc_d:.4f} | Δ={acc_p - acc_d:+.4f}")

    if not rows:
        print("  no rows produced — Table 4b cannot be completed yet.")
        return None

    out = pd.DataFrame(rows)
    out.to_csv(C.RESULTS / "table4b_translation_impact.csv", index=False)
    print(f"\n  wrote {C.RESULTS / 'table4b_translation_impact.csv'}")

    small = out[(out.n_degraded < 20) | (out.n_preserved < 20)]
    if not small.empty:
        print("\n  CAUTION: at least one subset has fewer than 20 comments. Report the")
        print("  sizes explicitly and present the comparison as indicative, not conclusive.")
    return out


def main():
    df = load_subset()
    print(f"gold-reference subset: {len(df)} comments, {C.TQ_REFS} independent references\n")
    surface_metrics(df)
    agreement(df)
    downstream_impact(df)


if __name__ == "__main__":
    main()
