"""
verify_consistency.py — reproduce Reviewer 3's audit on whatever is in the paper.

Run this against the values as typeset, not against tables.csv. It answers the
question "can a reader recompute my aggregate columns from my per-class
columns?" — which is exactly what the reviewer did.

Two modes:

  --from_csv artifacts/results/tables.csv
      checks the generated tables (should always pass)

  --from_manuscript manuscript_values.csv
      checks the values you actually typed into the paper. Prepare that file by
      transcribing the printed tables, then run this. If it disagrees with
      tables.csv, the transcription is wrong.

Expected columns in either file:
    task,modality,model,macro_f1,accuracy,P_<label>,R_<label>,...
"""

import argparse
import sys
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import config as C

# Test-partition supports for the fine-grained task (Sect. VI). Accuracy can be
# reconstructed from per-class recall and these supports.
FINE_SUPPORT = {"Gender": 341, "Political": 140, "Religion": 96,
                "Others": 112, "Violence": 55, "Geo-political": 46}

TOL_F1 = 0.015     # generous: per-class values are printed to 2 dp
TOL_ACC = 0.015


def f1(p, r):
    return 0.0 if (p + r) == 0 else 2 * p * r / (p + r)


def check_row(row) -> dict:
    labels = C.LABELS[row["task"]]
    per_class_f1 = []
    for lab in labels:
        pc, rc = f"P_{lab}", f"R_{lab}"
        if pc not in row or pd.isna(row[pc]):
            return dict(status="skipped", reason=f"missing {pc}")
        per_class_f1.append(f1(float(row[pc]), float(row[rc])))

    macro_calc = sum(per_class_f1) / len(labels)
    d_f1 = macro_calc - float(row["macro_f1"])

    d_acc, acc_calc = None, None
    if row["task"] == "multiclass":
        total = sum(FINE_SUPPORT.values())
        acc_calc = sum(FINE_SUPPORT[l] * float(row[f"R_{l}"]) for l in labels) / total
        d_acc = acc_calc - float(row["accuracy"])

    ok = abs(d_f1) <= TOL_F1 and (d_acc is None or abs(d_acc) <= TOL_ACC)
    return dict(status="OK" if ok else "FAIL", macro_calc=macro_calc, d_f1=d_f1,
                acc_calc=acc_calc, d_acc=d_acc)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--from_csv", type=Path, default=C.RESULTS / "tables.csv")
    ap.add_argument("--from_manuscript", type=Path, default=None)
    a = ap.parse_args()

    src = a.from_manuscript or a.from_csv
    if not src.exists():
        raise SystemExit(f"{src} not found")
    df = pd.read_csv(src)
    if "ablation" in df.columns:
        df = df[~df["ablation"].astype(bool)]

    print(f"auditing {src}\n")
    hdr = f"{'task':11}{'modality':12}{'model':12}{'F1 shown':>9}{'F1 calc':>9}{'Δ':>8}{'Acc shown':>10}{'Acc calc':>9}{'Δ':>8}  status"
    print(hdr)
    print("-" * len(hdr))

    failures = 0
    for _, row in df.iterrows():
        res = check_row(row)
        if res["status"] == "skipped":
            continue
        acc_c = f"{res['acc_calc']:9.4f}" if res["acc_calc"] is not None else f"{'—':>9}"
        d_acc = f"{res['d_acc']:+8.4f}" if res["d_acc"] is not None else f"{'—':>8}"
        print(f"{row['task']:11}{row['modality']:12}{row['model']:12}"
              f"{float(row['macro_f1']):9.4f}{res['macro_calc']:9.4f}{res['d_f1']:+8.4f}"
              f"{float(row['accuracy']):10.4f}{acc_c}{d_acc}  {res['status']}")
        if res["status"] == "FAIL":
            failures += 1

    print()
    if failures:
        print(f"{failures} row(s) FAILED. Do not submit these tables.")
        print("A row fails when its aggregate columns cannot be reconstructed from its")
        print("per-class columns. That means the two came from different sources —")
        print("regenerate both from the same prediction file.")
        sys.exit(1)
    print("all rows internally consistent: every aggregate value is reconstructible")
    print("from the per-class values printed beside it.")


if __name__ == "__main__":
    main()
