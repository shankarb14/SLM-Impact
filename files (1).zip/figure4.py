"""
figure4.py — effect of translation preprocessing on Macro-F1 (Figure 4, RQ2).

Each bar is Δ = Macro-F1(translated) − Macro-F1(code-mixed) for one model.
The figure and the mean Δ values quoted in the abstract, Sect. V-A and the
conclusion all come from here, so they cannot drift apart — which is how the
previous submission ended up with a Figure 4 that disagreed with Table 9.

    python -m analysis.figure4
"""

import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config as C

NEGLIGIBLE = 0.005
ORDER = C.STANDARD + C.COMPACT


def deltas(df: pd.DataFrame, task: str) -> pd.DataFrame:
    sub = df[df.task == task]
    wide = sub.pivot_table(index="model", columns="modality", values="macro_f1", aggfunc="mean")
    missing = [m for m in ORDER if m not in wide.index]
    if missing:
        raise SystemExit(f"no results for {missing} in task '{task}'")
    wide = wide.loc[ORDER]
    wide["delta"] = wide["translated"] - wide["codemixed"]
    return wide


def panel(ax, wide, title):
    ys = range(len(wide))
    for y, (model, row) in zip(ys, wide.iterrows()):
        d = row["delta"]
        color = "#9e9e9e" if abs(d) < NEGLIGIBLE else ("#2e7d32" if d > 0 else "#c62828")
        ax.barh(y, d, color=color, edgecolor="black", lw=0.5,
                hatch="//" if C.MODELS[model]["group"] == "compact" else None)
        ax.text(d + (0.006 if d >= 0 else -0.006), y, f"{d:+.4f}",
                va="center", ha="left" if d >= 0 else "right", fontsize=7.5, fontweight="bold")
    ax.axvline(0, color="black", lw=0.8, ls="--")
    ax.set_yticks(list(ys))
    ax.set_yticklabels(wide.index, fontsize=8.5)
    ax.invert_yaxis()
    ax.set_xlabel("Δ Macro-F1  (translated − code-mixed)", fontsize=9)
    ax.set_title(title, fontsize=10, fontweight="bold")
    ax.grid(axis="x", alpha=0.25, ls=":")
    mean = wide["delta"].mean()
    ax.text(0.97, 0.04, f"Mean Δ = {mean:+.4f}", transform=ax.transAxes,
            ha="right", fontsize=8.5, fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.35", fc="white", ec="#c62828"))
    return mean


def main():
    f = C.RESULTS / "tables.csv"
    if not f.exists():
        raise SystemExit("run evaluate_metrics.py first")
    df = pd.read_csv(f)
    df = df[~df["ablation"].astype(bool)]

    binary, multi = deltas(df, "binary"), deltas(df, "multiclass")

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11.5, 5))
    m_bin = panel(ax1, binary, "(a) Binary classification")
    m_mul = panel(ax2, multi, "(b) Fine-grained classification")
    lo = min(binary.delta.min(), multi.delta.min()) - 0.03
    hi = max(binary.delta.max(), multi.delta.max()) + 0.05
    ax1.set_xlim(lo, hi); ax2.set_xlim(lo, hi)

    fig.suptitle("Effect of translation preprocessing on Macro-F1",
                 fontsize=11.5, fontweight="bold")
    fig.text(0.5, 0.925, "Green: gain. Red: loss. Grey: |Δ| < 0.005. Hatched: distilled compact encoders.",
             ha="center", fontsize=8.5, style="italic")
    fig.tight_layout(rect=[0, 0, 1, 0.91])
    out = C.RESULTS / "figure4_translation_delta.png"
    fig.savefig(out, dpi=300)
    fig.savefig(out.with_suffix(".pdf"))

    both = pd.DataFrame({"binary_delta": binary.delta, "multiclass_delta": multi.delta})
    both.to_csv(C.RESULTS / "translation_deltas.csv")

    print(f"wrote {out}\n")
    print(both.round(4).to_string())
    print(f"\nmean Δ binary       = {m_bin:+.4f}")
    print(f"mean Δ fine-grained = {m_mul:+.4f}")
    print("\nQuote exactly these two means in the abstract, Sect. V-A and the conclusion.")


if __name__ == "__main__":
    main()
